<?php

if (!defined("ABSPATH")) {
    exit();
}

function wpDiscuz(){
    return WpdiscuzCore::getInstance();
}
